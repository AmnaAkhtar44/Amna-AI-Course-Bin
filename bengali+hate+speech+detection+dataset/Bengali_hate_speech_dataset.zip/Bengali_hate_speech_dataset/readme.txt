Warning: The data and lexicons contain contenst that are racist, sexist, homophobic, and offensive in many different ways. The dataset is collected and subsequently annotated only for research-related purposes. Besides, authors don't take any liability if some statements contain very offensive and hateful statements that are either directed towards a specific person or entity or generalized towards a group. Therefore, please use it at your risk.

More details: Please check https://github.com/rezacsedu/Bengali-Hate-Speech-Dataset for more details about this dataset. 

Citation request: Please cite the following two ppaers if you use this dataset for your research

1. Md. Rezaul Karim, Bharathi Raja Chakravarti, John P. McCrae, and Michael Cochez, “Classification Benchmarks for Under-resourced Bengali Language based on Multichannel Convolutional-LSTM Network”, Proc. of IEEE International Conference on Data Science and Advanced Analytics (DSAA’2020), Sydney, Australia, October 2020.
2. Md. Rezaul Karim, Sumon Kanti Dey, Tanhim Islam†, Sagor Sarker, Mehadi Hasan Menon, Kabir Hossain, Md. Azam Hossain, and Stefan Decker, “DeepHateExplainer: Explainable Hate Speech Detection in Under-resourced Bengali Language”, Proc. of IEEE International Conference on Data Science and Advanced Analytics (DSAA’2021), Portugal, October 6-9 2021. 

